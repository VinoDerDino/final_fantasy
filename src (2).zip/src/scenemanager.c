#include "scenemanager.h"

void changeScene(Scenemanager *manager, Scenetypes type) {
    switch (type) {
    case MENU:
        manager->OnSceneEnter = NULL;
        manager->OnSceneExit = NULL;
        manager->UpdateScene = NULL;
        manager->DrawScene = NULL;
        break;
    
    case OVERWORLD:
        manager->OnSceneEnter = NULL;
        manager->OnSceneExit = NULL;
        manager->UpdateScene = NULL;
        manager->DrawScene = NULL;
        break;

    case INVENTORY:
        manager->OnSceneEnter = NULL;
        manager->OnSceneExit = NULL;
        manager->UpdateScene = NULL;
        manager->DrawScene = NULL;
        break;

    default:
        break;
    }

    manager->is_first = true;
}

void updateScene(Scenemanager manager, void* userdata) {
    manager.UpdateScene(userdata);
}

void drawScene(Scenemanager manager) {
    manager.DrawScene();
}