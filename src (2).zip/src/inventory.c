#include "inventory.h"

void invOnEnter() {

}

void invOnExit() {

}

void invUpdate(void* userdata) {

}

void invDraw() {

}


void drawGrid() {
    pd->graphics->drawLine(250, 0, 250, 240, 2, kColorBlack);
}
