#include <stdio.h>
#include <stdlib.h>

#define TARGET_EXTENSION 1

#include "pd_api.h"
#include "menu.h"
#include "jsonparser.h"
#include "inventory.h"

#include "game.h"

static int update(void* userdata);

Game game;
PlaydateAPI *pd = NULL;

static Menu menu;
static bool first;

static int curr_item = 0;

#ifdef _WINDLL
__declspec(dllexport)
#endif

int eventHandler(PlaydateAPI* playdate, PDSystemEvent event, uint32_t arg) {
    (void)arg;
	pd = playdate;
    
	if (event == kEventInit) {
		pd->display->setRefreshRate(0);
		first = false;

		Scenemanager manager = {
			.OnSceneEnter = NULL,
			.OnSceneExit = NULL,
			.UpdateScene = NULL,
			.DrawScene = NULL,
			.is_first = true,
		};

		game.scenemanager = manager;

		game.itemtable = newBitmapTable("images/swag", pd, 50, 16, 16);
		decodeItems("jsons/test.json", &game.itemlist);


		menu_init(&menu, ITEMS, game.itemlist);

        pd->system->setUpdateCallback(update, pd);
    } 
     
    return 0;
}

static int update(void* userdata) {
	if(!first) {
		menu_draw(&menu, pd);
		first = true;
		drawSprite(game.itemlist.items[curr_item].icon, pd);
	}

	// pd->system->drawFPS(0, 0);

	PDButtons buttons;
    pd->system->getButtonState(NULL, &buttons, NULL);

	if(!buttons) return 1; 

	if(buttons & kButtonUp) {
		pd->graphics->fillRect(0, 0, 16, 16, kColorWhite);
		curr_item++;
		drawSprite(game.itemlist.items[curr_item].icon, pd);
		pd->system->logToConsole("Current item name: %s at id: %d", game.itemlist.items[curr_item].name, curr_item);
	} else if(buttons & kButtonDown) {
		pd->graphics->fillRect(0, 0, 16, 16, kColorWhite);
		curr_item--;
		drawSprite(game.itemlist.items[curr_item].icon, pd);
		pd->system->logToConsole("Current item name: %s at id: %d", game.itemlist.items[curr_item].name, curr_item);
	}


	menu_handle_input(&menu, buttons, pd);
    menu_draw(&menu, pd);

    return 1;
}