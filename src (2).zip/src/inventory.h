#ifndef INVENTORY_H_
#define INVENTORY_H_

#include "pd_api.h"
#include "item.h"
#include "player.h"
#include "sprite.h"

#define MAX_ITEMS_IN_INVENTORY 50
 
extern PlaydateAPI *pd;

typedef struct  {
    Item items[MAX_ITEMS_IN_INVENTORY];
    int curr_pos;
} Inventory;


void invOnEnter();
void invOnExit();
void invUpdate();
void invDraw();

#endif