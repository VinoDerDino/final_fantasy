#ifndef SCENEMANAGER_H_
#define SCENEMANAGER_H_

#include <stdbool.h>
#include <stddef.h>

typedef enum {
    MENU,
    OVERWORLD,
    INVENTORY,
} Scenetypes;

typedef struct {
    bool is_first;
    void (*OnSceneEnter)(void);
    void (*OnSceneExit)(void);
    void (*UpdateScene)(void* userdata);
    void (*DrawScene)(void);
} Scenemanager;

void changeScene(Scenemanager *manager, Scenetypes type);
void updateScene(Scenemanager manager, void* userdata);
void drawScene(Scenemanager manager);

#endif